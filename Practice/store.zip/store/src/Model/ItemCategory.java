package Model;

public enum ItemCategory {
    books,
    electronics,
    pets,
    food


}
