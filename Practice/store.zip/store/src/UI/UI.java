package UI;

import java.util.Scanner;

public class UI {
    private static Scanner scanner = new Scanner(System.in);

    public static void run() {

        int input;

        boolean exit = false;

        while (!exit) {

            System.out.println("-1 Mehsullar uzerinde emeliyyat aparmaq\n" +
                    "-2 Satislar uzerinde emeliyyat aparmaq\n" +
                    "-3 Sistemden cixmaq");

            System.out.print("Type (waiting...): ");

            input = scanner.nextInt();

            //

        }

    }
}
