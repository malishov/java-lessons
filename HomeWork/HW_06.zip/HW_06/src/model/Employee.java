package model;

public interface Employee {
    int getMonthSalary();
    void onFire();
    void onHire();
    String getName();
}
